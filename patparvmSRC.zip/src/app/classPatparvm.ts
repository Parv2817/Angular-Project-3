export class A3Classpatparvm
{
    fullName991718111!: string;
    id991718111!: number;
    email991718111!: string;
    login991718111!: string;
}